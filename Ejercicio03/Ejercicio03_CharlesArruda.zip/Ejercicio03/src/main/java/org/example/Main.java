package org.example;

import java.io.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Primero comando:");
        String cmd1 = scanner.nextLine();
        System.out.println("Segundo comando:");
        String cmd2 = scanner.nextLine();


        ProcessBuilder pb1;
        ProcessBuilder pb2 = new ProcessBuilder(cmd2.split(" "));
        try {
            pb1 = new ProcessBuilder(cmd1.split(" "));


            Process primeroProceso = pb1.start();
            BufferedReader leer = new BufferedReader(new InputStreamReader(primeroProceso.getInputStream()));


            String salidaProceso = getSalidaProceso(leer);

            Process p2 = pb2.start();


            escribir(p2, salidaProceso);


            leer(p2);

        } catch (Exception e) {
            System.err.println("Exception:" + e.getMessage());
        }
    }

    private static String getSalidaProceso(BufferedReader leer) throws IOException {
        String linea;
        String salidaProceso = "";
        while ((linea = leer.readLine()) != null) {
            salidaProceso+=linea+"\r\n";
        }
        return salidaProceso;
    }

    private static void leer(Process p2) throws IOException {
        String linea;
        BufferedReader leer = new BufferedReader(new InputStreamReader(p2.getInputStream()));
        while ((linea = leer.readLine()) != null) {
            System.out.println(linea);
        }
    }

    private static void escribir(Process p2, String salidaProceso) throws IOException {
        BufferedWriter escribir = new BufferedWriter(new OutputStreamWriter(p2.getOutputStream()));
        escribir.write(salidaProceso);
        escribir.close();
    }
}
